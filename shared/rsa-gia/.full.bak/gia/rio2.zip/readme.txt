GiA Roots is developed by a consortium of researchers at the 
Georgia Institute of Technology and Duke University.  It is 
currently in beta test mode.  Please refer to the manual for more
information on usage.  Questions about the software can be directed 
to gia-roots@biology.gatech.edu.

This product includes software developed by the OpenCV User Group.


